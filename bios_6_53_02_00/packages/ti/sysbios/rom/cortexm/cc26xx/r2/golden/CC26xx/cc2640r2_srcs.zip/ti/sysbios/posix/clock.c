/*
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 *  ======== clock.c ========
 */

#include <xdc/std.h>

#include <ti/sysbios/hal/Seconds.h>
#include <ti/sysbios/knl/Clock.h>

#include <ti/sysbios/posix/_time.h>
#include <ti/sysbios/posix/_pthread_error.h>

/*
 *  ======== clock_gettime ========
 */
int clock_gettime(clockid_t clockId, struct timespec *ts)
{
    Seconds_Time t;
    unsigned long secs;
    UInt32 ticks;

    if (clockId == CLOCK_REALTIME) {
        Seconds_getTime(&t);

        ts->tv_sec = t.secs;
        ts->tv_nsec = t.nsecs;
    }
    else {
        /* CLOCK_MONOTONIC */
        ticks = Clock_getTicks();
        secs = ((unsigned long)ticks * Clock_tickPeriod) / 1000000;
        ts->tv_sec = secs;
        ts->tv_nsec = ((unsigned long)ticks * Clock_tickPeriod -
                secs * 1000000) * 1000;
    }

    return (0);
}

/*
 *  ======== clock_settime ========
 */
int clock_settime(clockid_t clock_id, const struct timespec *ts)
{
    if (clock_id == CLOCK_MONOTONIC) {
        return (EINVAL);
    }

    Seconds_set(ts->tv_sec);

    return (0);
}
