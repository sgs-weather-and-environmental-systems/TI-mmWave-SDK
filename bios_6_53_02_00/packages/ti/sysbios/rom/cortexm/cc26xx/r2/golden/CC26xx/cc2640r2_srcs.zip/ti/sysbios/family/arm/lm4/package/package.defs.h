/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_family_arm_lm4__
#define ti_sysbios_family_arm_lm4__


/*
 * ======== module ti.sysbios.family.arm.lm4.Seconds ========
 */

typedef struct ti_sysbios_family_arm_lm4_Seconds_Module_State ti_sysbios_family_arm_lm4_Seconds_Module_State;
typedef struct ti_sysbios_family_arm_lm4_Seconds_Fxns__ ti_sysbios_family_arm_lm4_Seconds_Fxns__;
typedef const ti_sysbios_family_arm_lm4_Seconds_Fxns__* ti_sysbios_family_arm_lm4_Seconds_Module;

/*
 * ======== module ti.sysbios.family.arm.lm4.TimestampProvider ========
 */

typedef struct ti_sysbios_family_arm_lm4_TimestampProvider_Module_State ti_sysbios_family_arm_lm4_TimestampProvider_Module_State;
typedef struct ti_sysbios_family_arm_lm4_TimestampProvider_Fxns__ ti_sysbios_family_arm_lm4_TimestampProvider_Fxns__;
typedef const ti_sysbios_family_arm_lm4_TimestampProvider_Fxns__* ti_sysbios_family_arm_lm4_TimestampProvider_Module;

/*
 * ======== module ti.sysbios.family.arm.lm4.Timer ========
 */

typedef struct ti_sysbios_family_arm_lm4_Timer_TimerDevice ti_sysbios_family_arm_lm4_Timer_TimerDevice;
typedef struct ti_sysbios_family_arm_lm4_Timer_Module_State ti_sysbios_family_arm_lm4_Timer_Module_State;
typedef struct ti_sysbios_family_arm_lm4_Timer_Fxns__ ti_sysbios_family_arm_lm4_Timer_Fxns__;
typedef const ti_sysbios_family_arm_lm4_Timer_Fxns__* ti_sysbios_family_arm_lm4_Timer_Module;
typedef struct ti_sysbios_family_arm_lm4_Timer_Params ti_sysbios_family_arm_lm4_Timer_Params;
typedef struct ti_sysbios_family_arm_lm4_Timer_Object ti_sysbios_family_arm_lm4_Timer_Object;
typedef struct ti_sysbios_family_arm_lm4_Timer_Struct ti_sysbios_family_arm_lm4_Timer_Struct;
typedef ti_sysbios_family_arm_lm4_Timer_Object* ti_sysbios_family_arm_lm4_Timer_Handle;
typedef struct ti_sysbios_family_arm_lm4_Timer_Object__ ti_sysbios_family_arm_lm4_Timer_Instance_State;
typedef ti_sysbios_family_arm_lm4_Timer_Object* ti_sysbios_family_arm_lm4_Timer_Instance;


#endif /* ti_sysbios_family_arm_lm4__ */ 
