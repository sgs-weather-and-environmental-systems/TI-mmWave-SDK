/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_syncs__
#define ti_sysbios_syncs__


/*
 * ======== module ti.sysbios.syncs.SyncSem ========
 */

typedef struct ti_sysbios_syncs_SyncSem_Fxns__ ti_sysbios_syncs_SyncSem_Fxns__;
typedef const ti_sysbios_syncs_SyncSem_Fxns__* ti_sysbios_syncs_SyncSem_Module;
typedef struct ti_sysbios_syncs_SyncSem_Params ti_sysbios_syncs_SyncSem_Params;
typedef struct ti_sysbios_syncs_SyncSem_Object ti_sysbios_syncs_SyncSem_Object;
typedef struct ti_sysbios_syncs_SyncSem_Struct ti_sysbios_syncs_SyncSem_Struct;
typedef ti_sysbios_syncs_SyncSem_Object* ti_sysbios_syncs_SyncSem_Handle;
typedef struct ti_sysbios_syncs_SyncSem_Object__ ti_sysbios_syncs_SyncSem_Instance_State;
typedef ti_sysbios_syncs_SyncSem_Object* ti_sysbios_syncs_SyncSem_Instance;

/*
 * ======== module ti.sysbios.syncs.SyncSwi ========
 */

typedef struct ti_sysbios_syncs_SyncSwi_Fxns__ ti_sysbios_syncs_SyncSwi_Fxns__;
typedef const ti_sysbios_syncs_SyncSwi_Fxns__* ti_sysbios_syncs_SyncSwi_Module;
typedef struct ti_sysbios_syncs_SyncSwi_Params ti_sysbios_syncs_SyncSwi_Params;
typedef struct ti_sysbios_syncs_SyncSwi_Object ti_sysbios_syncs_SyncSwi_Object;
typedef struct ti_sysbios_syncs_SyncSwi_Struct ti_sysbios_syncs_SyncSwi_Struct;
typedef ti_sysbios_syncs_SyncSwi_Object* ti_sysbios_syncs_SyncSwi_Handle;
typedef struct ti_sysbios_syncs_SyncSwi_Object__ ti_sysbios_syncs_SyncSwi_Instance_State;
typedef ti_sysbios_syncs_SyncSwi_Object* ti_sysbios_syncs_SyncSwi_Instance;

/*
 * ======== module ti.sysbios.syncs.SyncEvent ========
 */

typedef struct ti_sysbios_syncs_SyncEvent_Fxns__ ti_sysbios_syncs_SyncEvent_Fxns__;
typedef const ti_sysbios_syncs_SyncEvent_Fxns__* ti_sysbios_syncs_SyncEvent_Module;
typedef struct ti_sysbios_syncs_SyncEvent_Params ti_sysbios_syncs_SyncEvent_Params;
typedef struct ti_sysbios_syncs_SyncEvent_Object ti_sysbios_syncs_SyncEvent_Object;
typedef struct ti_sysbios_syncs_SyncEvent_Struct ti_sysbios_syncs_SyncEvent_Struct;
typedef ti_sysbios_syncs_SyncEvent_Object* ti_sysbios_syncs_SyncEvent_Handle;
typedef struct ti_sysbios_syncs_SyncEvent_Object__ ti_sysbios_syncs_SyncEvent_Instance_State;
typedef ti_sysbios_syncs_SyncEvent_Object* ti_sysbios_syncs_SyncEvent_Instance;


#endif /* ti_sysbios_syncs__ */ 
