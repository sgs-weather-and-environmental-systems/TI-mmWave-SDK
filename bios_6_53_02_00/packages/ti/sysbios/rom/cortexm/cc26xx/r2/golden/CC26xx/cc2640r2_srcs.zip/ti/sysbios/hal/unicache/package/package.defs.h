/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_hal_unicache__
#define ti_sysbios_hal_unicache__


/*
 * ======== module ti.sysbios.hal.unicache.Cache ========
 */

typedef struct ti_sysbios_hal_unicache_Cache_CACHE ti_sysbios_hal_unicache_Cache_CACHE;
typedef struct ti_sysbios_hal_unicache_Cache_OCPConfig ti_sysbios_hal_unicache_Cache_OCPConfig;
typedef struct ti_sysbios_hal_unicache_Cache_SecurityConfig ti_sysbios_hal_unicache_Cache_SecurityConfig;
typedef struct ti_sysbios_hal_unicache_Cache_Fxns__ ti_sysbios_hal_unicache_Cache_Fxns__;
typedef const ti_sysbios_hal_unicache_Cache_Fxns__* ti_sysbios_hal_unicache_Cache_Module;

/*
 * ======== module ti.sysbios.hal.unicache.Cache_Module_GateProxy ========
 */

typedef struct ti_sysbios_hal_unicache_Cache_Module_GateProxy_Fxns__ ti_sysbios_hal_unicache_Cache_Module_GateProxy_Fxns__;
typedef const ti_sysbios_hal_unicache_Cache_Module_GateProxy_Fxns__* ti_sysbios_hal_unicache_Cache_Module_GateProxy_Module;
typedef struct ti_sysbios_hal_unicache_Cache_Module_GateProxy_Params ti_sysbios_hal_unicache_Cache_Module_GateProxy_Params;
typedef struct xdc_runtime_IGateProvider___Object *ti_sysbios_hal_unicache_Cache_Module_GateProxy_Handle;


#endif /* ti_sysbios_hal_unicache__ */ 
