/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_rom_cortexm_cc13xx__
#define ti_sysbios_rom_cortexm_cc13xx__


/*
 * ======== module ti.sysbios.rom.cortexm.cc13xx.CC13xx ========
 */

typedef struct ti_sysbios_rom_cortexm_cc13xx_CC13xx_Fxns__ ti_sysbios_rom_cortexm_cc13xx_CC13xx_Fxns__;
typedef const ti_sysbios_rom_cortexm_cc13xx_CC13xx_Fxns__* ti_sysbios_rom_cortexm_cc13xx_CC13xx_Module;


#endif /* ti_sysbios_rom_cortexm_cc13xx__ */ 
