/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_rom_cortexm_cc26xx__
#define ti_sysbios_rom_cortexm_cc26xx__


/*
 * ======== module ti.sysbios.rom.cortexm.cc26xx.CC26xx ========
 */

typedef struct ti_sysbios_rom_cortexm_cc26xx_CC26xx_Fxns__ ti_sysbios_rom_cortexm_cc26xx_CC26xx_Fxns__;
typedef const ti_sysbios_rom_cortexm_cc26xx_CC26xx_Fxns__* ti_sysbios_rom_cortexm_cc26xx_CC26xx_Module;


#endif /* ti_sysbios_rom_cortexm_cc26xx__ */ 
