/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_rom_c28_f28004x__
#define ti_sysbios_rom_c28_f28004x__


/*
 * ======== module ti.sysbios.rom.c28.f28004x.F28004x ========
 */

typedef struct ti_sysbios_rom_c28_f28004x_F28004x_Fxns__ ti_sysbios_rom_c28_f28004x_F28004x_Fxns__;
typedef const ti_sysbios_rom_c28_f28004x_F28004x_Fxns__* ti_sysbios_rom_c28_f28004x_F28004x_Module;


#endif /* ti_sysbios_rom_c28_f28004x__ */ 
