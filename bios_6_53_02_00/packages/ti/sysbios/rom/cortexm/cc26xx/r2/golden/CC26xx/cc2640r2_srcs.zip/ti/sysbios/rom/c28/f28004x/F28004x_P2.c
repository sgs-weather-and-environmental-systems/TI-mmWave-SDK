/*
 * Copyright (c) 2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== F28004x_P2.c ========
 *
 *  Application used to explicitly define each API required
 *  to be included the ROM.
 */

#define SWI_ENABLED 1
#define CREATES_ENABLED 1

#include <xdc/std.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Types.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/family/c28/Hwi.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Idle.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#if SWI_ENABLED
#include <ti/sysbios/knl/Swi.h>
#endif

#include <ti/sysbios/rom/c28/f28004x/F28004x.h>


void *memcpy(void *mem, const void *mem1, size_t n);

/*
 *  ======== main ========
 */
Int main(Int argc, Char* argv[])
{
    Task_Params taskParams;
    Clock_Params clockParams;
    Semaphore_Params semParams;
    Hwi_Params hwiParams;
#if SWI_ENABLED
    Swi_Params swiParams;
#endif

    /*
     * Allow this "application" to be executable
     */

    BIOS_start();

    /*
     * invoke all the APIs that must be pulled into ROM here
     */

    Task_Params_init(&taskParams);
    Clock_Params_init(&clockParams);
    Semaphore_Params_init(&semParams);
    Hwi_Params_init(&hwiParams);
#if SWI_ENABLED
    Swi_Params_init(&swiParams);
#endif


#if CREATES_ENABLED
    Task_create(Idle_loop, &taskParams, NULL);
    Semaphore_create(0, &semParams, NULL);
    Clock_create((Clock_FuncPtr)Idle_loop, 5, &clockParams, NULL);
    Hwi_create(16, (Hwi_FuncPtr)Idle_loop, &hwiParams, NULL);
 #if SWI_ENABLED
    Swi_create((Swi_FuncPtr)Idle_loop, &swiParams, NULL);
 #endif 
#endif

    Task_construct(NULL, Idle_loop, &taskParams, NULL);
    Semaphore_construct(NULL, 0, &semParams);
    Clock_construct(NULL, (Clock_FuncPtr)Idle_loop, 5, &clockParams);
    Hwi_construct(NULL, 16, (Hwi_FuncPtr)Idle_loop, &hwiParams, NULL);
#if SWI_ENABLED
    Swi_construct(NULL, (Swi_FuncPtr)Idle_loop, &swiParams, NULL);
#endif 

    Semaphore_pend(NULL, BIOS_WAIT_FOREVER);
    Semaphore_post(NULL);

    Clock_start((Clock_Handle)NULL);

    memcpy(NULL, 0, 0);

    return (0);
}

Void smallErrorPolicy(Error_Block *eb, Types_ModuleId mod, CString file,
                    Int line, Error_Id id, IArg arg1, IArg arg2)
{
    for (;;) {
    }
}

/*
 * memset, memclr, memcpy provided for ROM's usage to avoid external
 * reference to RTS lib funcs.
 *
 * These APIs are hidden in the TI application build flow to avoid
 * duplicate symbol warnings.
 */
void *memset(void *mem, int ch, size_t n)
{
    char *memp = (char *)mem;

    while (n--) {
        *memp++ = ch;
    }

    return (NULL);
}

void *memclr(void *mem, size_t n) {
    return(memset(mem, 0, n));
}

void *memcpy(void *d1, const void *s1, size_t n)
{
    char *src = (char *)s1;
    char *dst = (char *)d1;

    while (n--) {
        *dst++ = *src++;
    }

    return (NULL);
}

