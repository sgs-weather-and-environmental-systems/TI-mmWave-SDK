/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_timers_rti__
#define ti_sysbios_timers_rti__


/*
 * ======== module ti.sysbios.timers.rti.Timer ========
 */

typedef struct ti_sysbios_timers_rti_Timer_DeviceRegs ti_sysbios_timers_rti_Timer_DeviceRegs;
typedef struct ti_sysbios_timers_rti_Timer_TimerDevice ti_sysbios_timers_rti_Timer_TimerDevice;
typedef struct ti_sysbios_timers_rti_Timer_Module_State ti_sysbios_timers_rti_Timer_Module_State;
typedef struct ti_sysbios_timers_rti_Timer_Fxns__ ti_sysbios_timers_rti_Timer_Fxns__;
typedef const ti_sysbios_timers_rti_Timer_Fxns__* ti_sysbios_timers_rti_Timer_Module;
typedef struct ti_sysbios_timers_rti_Timer_Params ti_sysbios_timers_rti_Timer_Params;
typedef struct ti_sysbios_timers_rti_Timer_Object ti_sysbios_timers_rti_Timer_Object;
typedef struct ti_sysbios_timers_rti_Timer_Struct ti_sysbios_timers_rti_Timer_Struct;
typedef ti_sysbios_timers_rti_Timer_Object* ti_sysbios_timers_rti_Timer_Handle;
typedef struct ti_sysbios_timers_rti_Timer_Object__ ti_sysbios_timers_rti_Timer_Instance_State;
typedef ti_sysbios_timers_rti_Timer_Object* ti_sysbios_timers_rti_Timer_Instance;


#endif /* ti_sysbios_timers_rti__ */ 
