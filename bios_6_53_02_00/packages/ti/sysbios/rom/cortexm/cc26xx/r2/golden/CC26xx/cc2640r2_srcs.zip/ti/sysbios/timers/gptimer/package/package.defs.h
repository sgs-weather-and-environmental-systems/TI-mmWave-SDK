/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_timers_gptimer__
#define ti_sysbios_timers_gptimer__


/*
 * ======== module ti.sysbios.timers.gptimer.Timer ========
 */

typedef struct ti_sysbios_timers_gptimer_Timer_TiocpCfg ti_sysbios_timers_gptimer_Timer_TiocpCfg;
typedef struct ti_sysbios_timers_gptimer_Timer_Tier ti_sysbios_timers_gptimer_Timer_Tier;
typedef struct ti_sysbios_timers_gptimer_Timer_Twer ti_sysbios_timers_gptimer_Timer_Twer;
typedef struct ti_sysbios_timers_gptimer_Timer_Tclr ti_sysbios_timers_gptimer_Timer_Tclr;
typedef struct ti_sysbios_timers_gptimer_Timer_Tsicr ti_sysbios_timers_gptimer_Timer_Tsicr;
typedef struct ti_sysbios_timers_gptimer_Timer_TimerDevice ti_sysbios_timers_gptimer_Timer_TimerDevice;
typedef struct ti_sysbios_timers_gptimer_Timer_Module_State ti_sysbios_timers_gptimer_Timer_Module_State;
typedef struct ti_sysbios_timers_gptimer_Timer_Fxns__ ti_sysbios_timers_gptimer_Timer_Fxns__;
typedef const ti_sysbios_timers_gptimer_Timer_Fxns__* ti_sysbios_timers_gptimer_Timer_Module;
typedef struct ti_sysbios_timers_gptimer_Timer_Params ti_sysbios_timers_gptimer_Timer_Params;
typedef struct ti_sysbios_timers_gptimer_Timer_Object ti_sysbios_timers_gptimer_Timer_Object;
typedef struct ti_sysbios_timers_gptimer_Timer_Struct ti_sysbios_timers_gptimer_Timer_Struct;
typedef ti_sysbios_timers_gptimer_Timer_Object* ti_sysbios_timers_gptimer_Timer_Handle;
typedef struct ti_sysbios_timers_gptimer_Timer_Object__ ti_sysbios_timers_gptimer_Timer_Instance_State;
typedef ti_sysbios_timers_gptimer_Timer_Object* ti_sysbios_timers_gptimer_Timer_Instance;

/*
 * ======== module ti.sysbios.timers.gptimer.Timer_TimerSupportProxy ========
 */

typedef struct ti_sysbios_timers_gptimer_Timer_TimerSupportProxy_Fxns__ ti_sysbios_timers_gptimer_Timer_TimerSupportProxy_Fxns__;
typedef const ti_sysbios_timers_gptimer_Timer_TimerSupportProxy_Fxns__* ti_sysbios_timers_gptimer_Timer_TimerSupportProxy_Module;


#endif /* ti_sysbios_timers_gptimer__ */ 
