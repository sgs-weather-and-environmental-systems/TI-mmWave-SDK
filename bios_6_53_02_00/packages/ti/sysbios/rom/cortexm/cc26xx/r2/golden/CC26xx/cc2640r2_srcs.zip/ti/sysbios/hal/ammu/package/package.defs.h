/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_hal_ammu__
#define ti_sysbios_hal_ammu__


/*
 * ======== module ti.sysbios.hal.ammu.AMMU ========
 */

typedef struct ti_sysbios_hal_ammu_AMMU_MMU ti_sysbios_hal_ammu_AMMU_MMU;


#endif /* ti_sysbios_hal_ammu__ */ 
