/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_rts_iar__
#define ti_sysbios_rts_iar__


/*
 * ======== module ti.sysbios.rts.iar.MultithreadSupport ========
 */

typedef struct ti_sysbios_rts_iar_MultithreadSupport_Module_State ti_sysbios_rts_iar_MultithreadSupport_Module_State;


#endif /* ti_sysbios_rts_iar__ */ 
