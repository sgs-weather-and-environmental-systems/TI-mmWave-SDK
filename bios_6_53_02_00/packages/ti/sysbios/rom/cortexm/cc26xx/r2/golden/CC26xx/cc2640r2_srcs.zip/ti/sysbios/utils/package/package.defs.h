/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_utils__
#define ti_sysbios_utils__


/*
 * ======== module ti.sysbios.utils.Load ========
 */

typedef struct ti_sysbios_utils_Load_Stat ti_sysbios_utils_Load_Stat;
typedef struct ti_sysbios_utils_Load_HookContext ti_sysbios_utils_Load_HookContext;
typedef struct ti_sysbios_utils_Load_Module_State ti_sysbios_utils_Load_Module_State;


#endif /* ti_sysbios_utils__ */ 
