/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_timers_timer64__
#define ti_sysbios_timers_timer64__


/*
 * ======== module ti.sysbios.timers.timer64.Timer ========
 */

typedef struct ti_sysbios_timers_timer64_Timer_Control ti_sysbios_timers_timer64_Timer_Control;
typedef struct ti_sysbios_timers_timer64_Timer_EmuMgt ti_sysbios_timers_timer64_Timer_EmuMgt;
typedef struct ti_sysbios_timers_timer64_Timer_GpioIntEn ti_sysbios_timers_timer64_Timer_GpioIntEn;
typedef struct ti_sysbios_timers_timer64_Timer_GpioDatDir ti_sysbios_timers_timer64_Timer_GpioDatDir;
typedef struct ti_sysbios_timers_timer64_Timer_IntCtl ti_sysbios_timers_timer64_Timer_IntCtl;
typedef struct ti_sysbios_timers_timer64_Timer_TimerSetting ti_sysbios_timers_timer64_Timer_TimerSetting;
typedef struct ti_sysbios_timers_timer64_Timer_TimerDevice ti_sysbios_timers_timer64_Timer_TimerDevice;
typedef struct ti_sysbios_timers_timer64_Timer_Module_State ti_sysbios_timers_timer64_Timer_Module_State;
typedef struct ti_sysbios_timers_timer64_Timer_Fxns__ ti_sysbios_timers_timer64_Timer_Fxns__;
typedef const ti_sysbios_timers_timer64_Timer_Fxns__* ti_sysbios_timers_timer64_Timer_Module;
typedef struct ti_sysbios_timers_timer64_Timer_Params ti_sysbios_timers_timer64_Timer_Params;
typedef struct ti_sysbios_timers_timer64_Timer_Object ti_sysbios_timers_timer64_Timer_Object;
typedef struct ti_sysbios_timers_timer64_Timer_Struct ti_sysbios_timers_timer64_Timer_Struct;
typedef ti_sysbios_timers_timer64_Timer_Object* ti_sysbios_timers_timer64_Timer_Handle;
typedef struct ti_sysbios_timers_timer64_Timer_Object__ ti_sysbios_timers_timer64_Timer_Instance_State;
typedef ti_sysbios_timers_timer64_Timer_Object* ti_sysbios_timers_timer64_Timer_Instance;

/*
 * ======== module ti.sysbios.timers.timer64.TimestampProvider ========
 */

typedef struct ti_sysbios_timers_timer64_TimestampProvider_Module_State ti_sysbios_timers_timer64_TimestampProvider_Module_State;
typedef struct ti_sysbios_timers_timer64_TimestampProvider_Fxns__ ti_sysbios_timers_timer64_TimestampProvider_Fxns__;
typedef const ti_sysbios_timers_timer64_TimestampProvider_Fxns__* ti_sysbios_timers_timer64_TimestampProvider_Module;

/*
 * ======== module ti.sysbios.timers.timer64.Timer_TimerSupportProxy ========
 */

typedef struct ti_sysbios_timers_timer64_Timer_TimerSupportProxy_Fxns__ ti_sysbios_timers_timer64_Timer_TimerSupportProxy_Fxns__;
typedef const ti_sysbios_timers_timer64_Timer_TimerSupportProxy_Fxns__* ti_sysbios_timers_timer64_Timer_TimerSupportProxy_Module;


#endif /* ti_sysbios_timers_timer64__ */ 
