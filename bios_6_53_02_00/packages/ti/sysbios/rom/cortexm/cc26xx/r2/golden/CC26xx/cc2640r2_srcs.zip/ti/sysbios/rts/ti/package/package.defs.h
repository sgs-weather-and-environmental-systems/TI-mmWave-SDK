/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_rts_ti__
#define ti_sysbios_rts_ti__


/*
 * ======== module ti.sysbios.rts.ti.ThreadLocalStorage ========
 */

typedef struct ti_sysbios_rts_ti_ThreadLocalStorage_Module_State ti_sysbios_rts_ti_ThreadLocalStorage_Module_State;


#endif /* ti_sysbios_rts_ti__ */ 
