/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_rts_gnu__
#define ti_sysbios_rts_gnu__


/*
 * ======== module ti.sysbios.rts.gnu.ReentSupport ========
 */

typedef struct ti_sysbios_rts_gnu_ReentSupport_Module_State ti_sysbios_rts_gnu_ReentSupport_Module_State;

/*
 * ======== module ti.sysbios.rts.gnu.SemiHostSupport ========
 */



#endif /* ti_sysbios_rts_gnu__ */ 
